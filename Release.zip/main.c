#include "zombie_world.h"

int main()
{
    system("title ZOMBIE WORLD");
    playingmenuSelect();
    playingbazuka();
    playingbazukaExplosion();
    playingchooseMenu();
    playingItemEffect1();
    playingItemEffect2();
    playingItemEffect3();
    playingmenuSelect();
    playingshotgun();
    playingsniper();
    playingstageClear();
    playingtypingSound();
    playingweapon1and2();
    playingwinGame();
    playinghurt();
    playingmachineGun();
    playingBgm();
    ChooseMenu();
    return 0;
}